
--------------------------------------------------
---------------- CREATE DIM TABLES ---------------
--------------------------------------------------


--============================================
---------------- Dim_states 
--============================================


CREATE TABLE Dim_States (
    State_SK INT IDENTITY(1,1) PRIMARY KEY,
    State_ID INT,
    State_Name NVARCHAR(45),

    Valid_From DATE,
    Valid_To DATE
);
---------------------
ALTER TABLE Dim_States
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_States
ALTER COLUMN Valid_To DATETIME;
- -----------

--============================================
----------------  Dim_cities 
--============================================

CREATE TABLE Dim_Cities (
    City_SK INT IDENTITY(1,1) PRIMARY KEY,
    City_ID INT,
    City_Name NVARCHAR(20),
    State_Name NVARCHAR(45),

    Valid_From DATE,
    Valid_To DATE
);
------------------------
ALTER TABLE Dim_Cities
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_States
ALTER COLUMN Valid_To DATETIME;


--============================================
----------------  Dim_locations  
--============================================

CREATE TABLE Dim_Locations (
    Location_SK INT IDENTITY(1,1) PRIMARY KEY,
    Location_ID INT,
    Bank_Branch NVARCHAR(30),
    City_Name NVARCHAR(20),
    State_Name NVARCHAR(45),

    Valid_From DATE,
    Valid_To DATE
);

------------------
ALTER TABLE Dim_Locations
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Locations
ALTER COLUMN Valid_To DATETIME;


--============================================
---------------- Dim_categories
--============================================

CREATE TABLE Dim_Categories (
    Category_SK INT IDENTITY(1,1) PRIMARY KEY,
    Category_ID INT,
    Category_Name NVARCHAR(20),

    Valid_From DATE,
    Valid_To DATE
);
-----------------
ALTER TABLE Dim_Categories
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Categories
ALTER COLUMN Valid_To DATETIME;


--============================================
---------------- Dim_merchants 
--============================================


CREATE TABLE Dim_Merchants (
    Merchant_SK INT IDENTITY(1,1) PRIMARY KEY,
    Merchant_ID NVARCHAR(40),
    Category_Name NVARCHAR(20),

    Valid_From DATE,
    Valid_To DATE
);
-------------------------
ALTER TABLE Dim_Merchants
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Merchants
ALTER COLUMN Valid_To DATETIME;



--============================================
---------------- Dim_customers 
--============================================


CREATE TABLE Dim_Customers (
    Customer_SK INT IDENTITY(1,1) PRIMARY KEY,
    Customer_ID NVARCHAR(40),
    Customer_Name NVARCHAR(30),
    Gender NVARCHAR(10),
    Age INT,
    Customer_Contact NVARCHAR(14),
    Customer_Email NVARCHAR(30),
    Fraud_Trans INT,
    Is_Banned INT,

    Valid_From DATE,
    Valid_To DATE
);
-------------------------
ALTER TABLE Dim_Customers
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Customers
ALTER COLUMN Valid_To DATETIME;



--============================================
---------------- Dim_Accounts 
--============================================

CREATE TABLE Dim_Accounts (
    Account_SK INT IDENTITY(1,1) PRIMARY KEY,
    Account_ID INT,
    Customer_Name NVARCHAR(30),
    Gender NVARCHAR(10),
    Age INT,
    Customer_Contact NVARCHAR(14),
    Customer_Email NVARCHAR(30),
    Fraud_Trans INT,
    Is_Banned INT,
    Account_Type NVARCHAR(10),

    Valid_From DATE,
    Valid_To DATE
);
-----------------------
ALTER TABLE Dim_Accounts
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Accounts
ALTER COLUMN Valid_To DATETIME;



--============================================
---------------- Dim_Device 
--============================================

CREATE TABLE Dim_Device
(
    Device_SK INT IDENTITY(1,1) PRIMARY KEY,
    Device_ID  INT,
    Device_Type NVARCHAR(10),
    Transaction_Description NVARCHAR(35),

    Valid_From DATE,
    Valid_To DATE
);

---------------

ALTER TABLE Dim_Device
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Device
ALTER COLUMN Valid_To DATETIME;


--============================================
---------------- Dim_Transaction 
--============================================

CREATE TABLE Dim_Transaction
(
    Transaction_SK INT IDENTITY(1,1) PRIMARY KEY,
    Transaction_ID NVARCHAR(40),
    Transaction_Type NVARCHAR(15),
    Transaction_Description NVARCHAR(35),
    Is_Fraud INT NOT NULL CHECK (Is_Fraud IN (0,1)),

    Transaction_Device NVARCHAR(30),
    Device_Type NVARCHAR(10),

    Bank_Branch NVARCHAR(30),
    City_Name NVARCHAR(20),
    State_Name NVARCHAR(45),

    Category_Name NVARCHAR(20),

    Customer_Name NVARCHAR(30),
    Gender NVARCHAR(10),
    Age INT,
    Customer_Contact NVARCHAR(14),
    Customer_Email NVARCHAR(30),
    Fraud_Trans INT,
    Is_Banned INT,
    Account_Type NVARCHAR(10),

    Valid_From DATE,
    Valid_To DATE
);
----------------------------

ALTER TABLE Dim_Transaction
ALTER COLUMN Valid_From DATETIME;

ALTER TABLE Dim_Transaction
ALTER COLUMN Valid_To DATETIME;


--============================================
---------------- Dim_Date 
--============================================

CREATE TABLE Dim_Date
(
    Datekey INT PRIMARY KEY,           
    FullDate DATE NOT NULL,            
    Day INT NOT NULL,                  
    Month INT NOT NULL,                
    MonthName VARCHAR(20) NOT NULL,    
    Quarter INT NOT NULL,              
    Year INT NOT NULL,                 
    WeekOfYear INT NOT NULL,           
    DayOfWeek INT NOT NULL,            
    DayName VARCHAR(20) NOT NULL,      
    IsWeekend BIT NOT NULL             
);

-----------------------------------------------------
ALTER TABLE Dim_Date
ALTER COLUMN FullDate DATETIME
-----------------------------------------------------
--===================================================

DECLARE @StartDate DATE = '2015-01-01';
DECLARE @EndDate   DATE = '2035-12-31';

;WITH DateSequence AS
(
    SELECT @StartDate AS FullDate
    UNION ALL
    SELECT DATEADD(DAY, 1, FullDate)
    FROM DateSequence
    WHERE FullDate < @EndDate
)
INSERT INTO Dim_Date
(
    DateKey, FullDate, Day, Month, MonthName, Quarter, Year,
    WeekOfYear, DayOfWeek, DayName, IsWeekend
)
SELECT
    CONVERT(INT, FORMAT(FullDate, 'yyyyMMdd')) AS DateKey,
    FullDate,
    DAY(FullDate) AS Day,
    MONTH(FullDate) AS Month,
    DATENAME(MONTH, FullDate) AS MonthName,
    DATEPART(QUARTER, FullDate) AS Quarter,
    YEAR(FullDate) AS Year,
    DATEPART(WEEK, FullDate) AS WeekOfYear,
    DATEPART(WEEKDAY, FullDate) AS DayOfWeek,
    DATENAME(WEEKDAY, FullDate) AS DayName,
    CASE WHEN DATENAME(WEEKDAY, FullDate) IN ('Saturday','Sunday') THEN 1 ELSE 0 END AS IsWeekend
FROM DateSequence
OPTION (MAXRECURSION 0);

----------------------------------------------------------
--- TO CHANGE THE TYPR OF DATA FROM DATE TO DATETIME ----- 
----------------------------------------------------------
DELETE FROM Dim_Date;


DECLARE @StartDate DATETIME = '2015-01-01 00:00:00';
DECLARE @EndDate   DATETIME = '2035-12-31 00:00:00';

;WITH DateSequence AS
(
    SELECT @StartDate AS FullDate
    UNION ALL
    SELECT DATEADD(DAY, 1, FullDate)
    FROM DateSequence
    WHERE FullDate < @EndDate
)
INSERT INTO Dim_Date
(
    DateKey, FullDate, Day, Month, MonthName, Quarter, Year,
    WeekOfYear, DayOfWeek, DayName, IsWeekend
)
SELECT
    CONVERT(INT, FORMAT(FullDate, 'yyyyMMdd')) AS DateKey,
    CAST(FullDate AS DATETIME) AS FullDate,
    DAY(FullDate) AS Day,
    MONTH(FullDate) AS Month,
    DATENAME(MONTH, FullDate) AS MonthName,
    DATEPART(QUARTER, FullDate) AS Quarter,
    YEAR(FullDate) AS Year,
    DATEPART(WEEK, FullDate) AS WeekOfYear,
    DATEPART(WEEKDAY, FullDate) AS DayOfWeek,
    DATENAME(WEEKDAY, FullDate) AS DayName,
    CASE WHEN DATENAME(WEEKDAY, FullDate) IN ('Saturday','Sunday') THEN 1 ELSE 0 END AS IsWeekend
FROM DateSequence
OPTION (MAXRECURSION 0);




--------------------------------------------------
---------------- CREATE FACT TABLE ---------------
--------------------------------------------------


CREATE TABLE Fact_Table (
    State_SK INT NOT NULL,
    City_SK INT NOT NULL,
    Location_SK INT NOT NULL,
    Category_SK INT NOT NULL,
    Merchant_SK INT NOT NULL,
    Customer_SK INT NOT NULL,
    Account_SK INT NOT NULL,   
    Transaction_SK INT NOT NULL,
    DateKey INT NOT NULL,
    

    Account_Balance FLOAT,

    CONSTRAINT fk_state FOREIGN KEY (State_SK) REFERENCES Dim_States(State_SK),
    CONSTRAINT fk_city FOREIGN KEY (City_SK) REFERENCES Dim_Cities(City_SK),
    CONSTRAINT fk_location FOREIGN KEY (Location_SK) REFERENCES Dim_Locations(Location_SK),
    CONSTRAINT fk_category FOREIGN KEY (Category_SK) REFERENCES Dim_Categories(Category_SK),
    CONSTRAINT fk_merchant FOREIGN KEY (Merchant_SK) REFERENCES Dim_Merchants(Merchant_SK),
    CONSTRAINT fk_customer FOREIGN KEY (Customer_SK) REFERENCES Dim_Customers(Customer_SK),
    CONSTRAINT fk_account FOREIGN KEY (Account_SK) REFERENCES Dim_Accounts(Account_SK),
    CONSTRAINT fk_transaction FOREIGN KEY (Transaction_SK) REFERENCES Dim_Transaction(Transaction_SK),
    CONSTRAINT fk_fact_date FOREIGN KEY (DateKey) REFERENCES Dim_Date(DateKey)
);

--===================================================


ALTER TABLE Fact_Table
ADD Transaction_Amount FLOAT;

--===================================================


ALTER TABLE Fact_Table
ADD Device_SK INT NOT NULL;

--===================================================


ALTER TABLE Fact_Table
ADD CONSTRAINT fk_device FOREIGN KEY (Device_SK)
REFERENCES Dim_Device(Device_SK);

