USE Payment_Fraud_DB

--============================================
------------ FOR Dim_States 
--============================================

SELECT S.State_ID,S.State_Name
FROM States S


--============================================
------------ FOR Dim_Cities 
--============================================

SELECT C.City_ID, C.City_Name, S.State_Name
FROM Cities C
INNER JOIN States S
ON C.State_ID = S.State_ID


--============================================
------------ FOR Dim_Location
--============================================


SELECT L.Location_ID, L.Bank_Branch, C.City_Name, S.State_Name 
FROM Locations L
INNER JOIN Cities C
ON L.City_ID = C.City_ID
INNER JOIN States S
ON C.State_ID = S.State_ID


--============================================
------------ FOR Dim_Categories 
--============================================



SELECT Category_ID,Category_Name 
FROM Merchant_Categories


--============================================
------------ FOR Dim_Merchent 
--============================================


SELECT M.Merchant_ID, Cat.Category_Name
FROM Merchants M
INNER JOIN Merchant_Categories Cat
ON M.Category_ID = Cat.Category_ID



--============================================
------------ FOR Dim_Customers
--============================================

SELECT Customer_ID, Customer_Name,Gender,Age,Customer_Contact
,Customer_Email, Fraud_Trans,Is_Banned
FROM Customers 


--============================================
------------ FOR Dim_Accounts
--============================================


SELECT A.Account_ID,cust.Customer_Name,cust.Gender,cust.Age,cust.Customer_Contact,
cust.Customer_Email,cust.Fraud_Trans,cust.Is_Banned,A.Account_Type
FROM Accounts A
INNER JOIN Customers cust
ON A.Customer_ID = cust.Customer_ID


--============================================
-------------- FOR Dim_Device 
--============================================


SELECT Device_ID,Device_Type,Transaction_Device
FROM Devices



--============================================
-------------- FOR Dim_Transaction 
--============================================



SELECT T.Transaction_ID,T.Transaction_Type,T.Transaction_Description,T.Is_Fraud,
       D.Transaction_Device,D.Device_Type,
       L.Bank_Branch,
       C.City_Name,
       S.State_Name,
       MC.Category_Name,
       A.Account_Type,
       Cust.Customer_Name,Cust.Gender,Cust.Age,Cust.Customer_Contact,
       Cust.Customer_Email,Cust.Fraud_Trans,Cust.Is_Banned
FROM Transactions T
INNER JOIN Devices D
ON T.Device_ID = D.Device_ID
INNER JOIN Locations L
ON L.Location_ID = T.Location_ID
INNER JOIN Cities C
ON L.City_ID = C.City_ID
INNER JOIN States S
ON S.State_ID = C.State_ID
INNER JOIN Merchants M
ON M.Merchant_ID = T.Merchant_ID
INNER JOIN Merchant_Categories MC
ON MC.Category_ID = M.Category_ID
INNER JOIN Accounts A
ON A.Account_ID =T.Account_ID
INNER JOIN Customers Cust
ON Cust.Customer_ID = A.Customer_ID


--============================================
-------------- FOR Fact_Table
--============================================


SELECT S.State_ID,C.City_ID,L.Location_ID,T.Transaction_ID,
       A.Account_ID,Cust.Customer_ID,M.Merchant_ID,MC.Category_ID,
       D.Device_ID,A.Account_Balance,T.Transaction_Amount,
       CAST(T.Transaction_Date AS DATETIME) AS Transaction_Date
FROM States S
INNER JOIN Cities C
ON S.State_ID = C.State_ID
INNER JOIN Locations L
ON L.City_ID = C.City_ID
INNER JOIN Transactions T
ON T.Location_ID = L.Location_ID
INNER JOIN Accounts A
ON A.Account_ID = T.Account_ID
INNER JOIN Customers Cust
ON Cust.Customer_ID = A.Customer_ID
INNER JOIN Merchants M
ON M.Merchant_ID = T.Merchant_ID
INNER JOIN Merchant_Categories MC
ON MC.Category_ID = M.Category_ID
INNER JOIN Devices D
ON D.Device_ID = T.Device_ID
 --------------------------------------------------------